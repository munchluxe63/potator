Potator port for GCW0 and TI Nspire CX (Native).

It's based on Alekmaul's Potator and tries to improve it with its first goal
of having proper emulation and good speed on GCW0.
